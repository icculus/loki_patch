#!/bin/sh
#
# This script is executed after the patch is applied

: echo "This is a post-patch script for $1 installed in $2"

exit 0
