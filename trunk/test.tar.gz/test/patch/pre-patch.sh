#!/bin/sh
#
# This script is executed before the patch is applied

: echo "This is a pre-patch script for $1 installed in $2"

exit 0
